#include "lzw.h"

#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

constexpr int MAX_CODE = 65535;

std::vector<int> compress(const std::string &input) {
  if (input.empty()) {
    return {};
  }

  std::unordered_map<std::string, int> dict;

  for (std::size_t i = 0; i < 256; ++i) {
    dict[std::string(1, static_cast<char>(i))] = i;
  }

  int nextCode = 256;

  std::vector<int> output;

  // alg to compress
  std::string curr;

  for (char c : input) {
    std::string candidate = curr + c;
    if (dict.contains(candidate)) {
      curr = candidate;
    } else {
      output.push_back(dict.at(curr));
      if (nextCode <= MAX_CODE) {
        dict[candidate] = nextCode;
        ++nextCode;
      }
      curr = std::string(1, c);
    }
  }
  if (!curr.empty()) {
    output.push_back(dict.at(curr));
  }

  return output;
}

std::string decompress(const std::vector<int> &codes) {
  if (codes.empty()) {
    return "";
  }

  std::unordered_map<int, std::string> dict;

  for (std::size_t i = 0; i < 256; ++i) {
    dict[i] = std::string(1, static_cast<char>(i));
  }

  int nextCode = 256;
  if (!dict.contains(codes[0])) {
    throw std::runtime_error("invalid lzw header code");
  }
  std::string prev = dict.at(codes[0]);
  std::string output = prev;

  for (size_t i = 1; i < codes.size(); ++i) {
    int code = codes[i];
    std::string curr;
    if (dict.contains(code)) {
      curr = dict.at(code);
    } else if (code == nextCode && nextCode <= MAX_CODE) {
      curr = prev + prev[0];
    } else {
      throw std::runtime_error("invalid lzw codes");
    }

    output += curr;

    if (nextCode <= MAX_CODE) {
      dict[nextCode] = prev + curr[0];
      ++nextCode;
    }
    prev = curr;
  }

  return output;
}
